#!/usr/bin/env sh
set -eu
game_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$game_dir"
exec ./EntreFolhas.x86_64 "$@"
